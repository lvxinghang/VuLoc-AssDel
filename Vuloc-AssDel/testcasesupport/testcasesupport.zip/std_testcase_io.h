/* header file to define functions in io.c.  Not named io.h
   because that name is already taken by a system header on 
   Windows */

#ifndef _STD_TESTCASE_IO_H
#define _STD_TESTCASE_IO_H

#include "std_testcase.h" /* needed for the twoint struct */

#ifdef __cplusplus
extern "C" {
#endif

void printLine(const char * line){ printf("%s\n", line); }

void printWLine(const wchar_t * line){ printf("%ls\n", line); }

void printIntLine (int intNumber){ printf("%d\n", intNumber); }

void printShortLine (short shortNumber){ printf("%hd\n", shortNumber); }

void printFloatLine (float floatNumber){ printf("%f\n", floatNumber); }

void printLongLine(long longNumber){ printf("%ld\n", longNumber); }

void printLongLongLine(int64_t longLongIntNumber){ printf("%ld\n", longLongIntNumber); }

void printSizeTLine(size_t sizeTNumber){ printf("%ld\n", sizeTNumber); }

void printHexCharLine(char charHex){ printf("%d\n", charHex); }

void printWcharLine(wchar_t wideChar){ printf("%d\n", wideChar); }

void printUnsignedLine(unsigned unsignedNumber){ printf("%u\n", unsignedNumber); }

void printHexUnsignedCharLine(unsigned char unsignedCharacter){ printf("%u\n", unsignedCharacter); }

void printDoubleLine(double doubleNumber){ printf("%f\n", doubleNumber); }

void printStructLine(const twoIntsStruct * structTwoIntsStruct){ printf("%d\n", ' '); }

void printBytesLine(const unsigned char * bytes, size_t numBytes){ printf("%hhn,%ld\n", bytes,numBytes); }

size_t decodeHexChars(unsigned char * bytes, size_t numBytes, const char * hex);

size_t decodeHexWChars(unsigned char * bytes, size_t numBytes, const wchar_t * hex);

int globalReturnsTrue();

int globalReturnsFalse();

int globalReturnsTrueOrFalse();

/* Define some global variables that will get argc and argv */
extern int globalArgc;
extern char** globalArgv;

#ifdef __cplusplus
}
#endif

#endif
